class IndexOutOfBounds(Exception):
    pass

class NotFound(Exception):
    pass

class Empty(Exception):
    pass


class ArrayList:
    def __init__(self):
        self.size = 0
        self.capacity = 4
        self.array = [0] * self.capacity
        self.ordered = False


    def print(self):
        print_str = ""
        for i in self.array:
            if i == 0:
                continue
            else:
                print_str += str(i) + ", "
        print(print_str[:-2])


    def prepend(self, value):
        if self.capacity == self.size:
            self.resize()
        for x in range(self.size-1, -1, -1):
            temp = self.array[x]
            self.array[x + 1] = temp
        self.size += 1
        self.array[0] = value       
        self.ordered = False


    def insert(self, value, index):
        if self.capacity == self.size:
            self.resize()
        for x in range(self.size - 1, index-1, -1):
            temp = self.array[x]
            if self.array[x+1] != 0:
                index += 1
            else:
                self.array[x + 1] = temp
        self.size += 1 
        self.array[index] = value
        self.ordered = False


    def append(self, value):
        if self.size == self.capacity:
            self.resize()
        self.array[self.size] = value
        self.size += 1
        self.ordered = False


    def set_at(self, value, index):
        self.array[index] = value 
        self.ordered = False


    def get_first(self):
        if self.size == 0:
            raise Empty
        elif self.size < 1:
            raise IndexOutOfBounds
        else:
            return self.array[0]


    def get_at(self, index):
        if self.size == 0:
            raise IndexOutOfBounds
        elif (self.size - 1) < index:
            raise IndexOutOfBounds
        else:
            return self.array[index]
        

    def get_last(self):
        index = -1
        if self.size == 0:
            raise Empty
        else:
            while self.array[index] == 0:
                index -= 1
        return self.array[index]


    def resize(self):
        self.capacity = self.capacity * 2
        new_arr = [0] * self.capacity
        for i in range(self.size):
            new_arr[i] = self.array[i]
        self.array = new_arr


    def remove_at(self, index):
        for x in range(index, self.size):
            if x != self.size:
                self.array[x] = self.array[x + 1]
        self.size -= 1


    def clear(self):
        for x in range(self.size):
            self.array[x] = 0
        self.__init__()


    def switch_index(self, index):
        temp = self.array[index]
        self.array[index] = self.array[index+1]
        self.array[index+1] = temp


    def insert_ordered(self, value):
        if self.array[0] < value < (self.size-1):
            self.append(value)          # kallað í ArrayList.append() fallið
            self.sort()                 # kallað í ArrayList.sort() fallið
        elif value < self.array[0]:
            self.prepend(value)
        else:
            self.append(value)
        self.size += 1
        self.ordered = True


    def sort(self):
        for _ in range(self.size):
            for j in range(1, self.size):
                if self.array[j-1] > self.array[j]:
                    self.array[j-1], self.array[j] = self.array[j], self.array[j-1]
        self.ordered = True


    def find(self, value):
        if self.ordered == True:
            index = self.binary_search(self.array, 0, self.size-1, value)
            if index != -1:
                return index
        else:    
            for i in range(self.size):
                if self.array[i] == value:
                    return i
        raise NotFound


    def binary_search(self, a_list, low, high, value):
        mid = (low + high) // 2
        if low > high:
            return -1
        if a_list[mid] == value:
            return mid
        elif a_list[mid] > value:
            return self.binary_search(a_list, low, mid-1, value)
        elif a_list[mid] < value:
            return self.binary_search(a_list, mid+1, high, value)


    def remove_value(self, value):
        index = self.find(value)
        self.remove_at(index)
        self.size -= 1


