from django.apps import AppConfig


class RealEstateConfig(AppConfig):
    name = 'RealEstate'
