// JavaScript file to get different urls for different order by outcomes.

function real_estate_urls() {
  window.location = document.getElementById("real_estate_order").value
}
