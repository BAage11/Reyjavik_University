1. Save python file in the same folder as the textfiles "init-no-dp.txt" and "input-no-dp.txt".
2. Run the python script "project2.py" in terminal within Visual Studio Code.
3. An output file, "output-no-dp.txt", should thereby be created within the same folder as the other files.