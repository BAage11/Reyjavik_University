1. Save python file in the same folder as the textfiles "init-dp.txt" and "input-dp.txt".
2. Run the python script "project2dp.py" in terminal within Visual Studio Code.
3. An output file, "output-dp.txt", should thereby be created within the same folder as the other files.